var maxResults = 1000;
var ctJson = "application/json";

function execute() {
    DL.logMessage("****** START EXECUTING OF GOOGLE CLOUD SCRIPT ******");
	
	var queryObject = getQueryObject();

    if (isValidProjectId(queryObject.projectId)) {
        var url = buildJobUrl(queryObject.projectId);
        var body = JSON.stringify(getJobBody(queryObject.query));
		DL.logMessage("Making request to " + url);
		var response = DL.REST.httpPost(url, ctJson, body);
		DL.logMessage("Job creation request completed with status code: " + response.getCode());
		
        if (response.getCode() == 200) {
            var payload = JSON.parse(response.getPayload());
            var jobReference = payload.jobReference;
            if (jobReference !== null && jobReference.jobId) {
                var jobId = jobReference.jobId;
                DL.logMessage("Job created for the query with job id: " + jobId);

                url = buildUrlWithJobId(url, jobId);
                var instanceUrl = url;
                DL.logMessage("Making request to " + url);
                response =  DL.REST.httpGet(url);

                if (response.getCode() == 200) {
                    payload = JSON.parse(response.getPayload());
                    
                    if (payload.rows) {
                        DL.logMessage("****** Starting chunk upload *****");
                        DL.Apptio.startChunkedUpload(ctJson);
                        
                        DL.logMessage("****** Uploading chunk *****");
                        DL.Apptio.uploadChunk(JSON.stringify(prepareChunkForUpload(payload).chunk));

                        while (payload.pageToken) {
                            url = instanceUrl + payload.pageToken;
                            DL.logMessage("Making request to " + url);
                            response = DL.REST.httpGet(url);
                            if (response.getCode() == 200) {
                                payload = JSON.parse(response.getPayload());
                                if (payload.rows) {
                                    DL.logMessage("****** Uploading chunk *****");
                                    DL.Apptio.uploadChunk(JSON.stringify(prepareChunkForUpload(payload).chunk));
                                }
                            } else {
                                DL.logMessage("Failed to retrieve remaining records; uploading current set");
                                break;
                            }
                        }

                        DL.Apptio.endChunkedUpload();
                        DL.logMessage("****** Upload chunk completed *****");
                    } else {
                        DL.logMessage("No records found!");
                    }
                } else {
                    DL.logMessage("Failed to retrieve job details with status code: " + response.getCode());    
                }

            } else {
                DL.logMessage("Failed to create job.");  
            }
        } else {
            DL.logMessage("Failed to create job with status code: " + response.getCode());
        }
    } else {
        DL.logMessage("Invalid Project Id.");
    }
}

function test() {
    DL.logMessage("****** START TESTING SCRIPT - GOOGLE CLOUD ******");

    var queryObject = getQueryObject();
    if (queryObject.projectId !== null) {
        var url = getBaseUrl() + "/bigquery/v2/projects";

        var response = DL.REST.httpGet(url);
        if(response.getCode() === 200) {
            DL.logMessage("Google Cloud URL and credentials are valid.");
        } else {
            DL.terminate("Request failed with status code " + response.getCode());
        }
    } else {
        DL.logMessage("***** Project Id is empty *****");
    }
}

function getBaseUrl() {
    var baseUrl = DL.REST.Source.getUrl();
    var url = DL.REST.rebuildUrl(baseUrl, true, false, false, false);
    if (url.endsWith('/')) {
        url = url.substr(0, url.length - 1);
    }
    return url;
}

function buildJobUrl(projectId) {
    return getJobUrl(getProjectsUrl(getBaseUrl()), projectId);
}

function getJobUrl(url, projectId) {
    return url + projectId + "/queries";
}

function getProjectsUrl(url) {
    return url + "/bigquery/v2/projects/";
}

function getJobBody(query) {
	return {
        "query": query,
        "maxResults": maxResults,
        "useLegacySql": true
    };
}

function getQueryObject() {
	var query = DL.REST.Source.getProperty("bigQuery").trim();
	var projectId = "";

	if (query) {
		projectId = getProjectIdFromQuery(query);
	} else {
		var tableId = DL.REST.Source.getProperty("tableId").trim();
		if (tableId) {
			projectId = getProjectIdFromTableId(tableId);
			var timeGranularity = getTimeGranularity();
			query = "SELECT service.description as serviceName,sku.description as skuDescription, usage_start_time,usage_end_time, project.id as  projectId, project.name as projectName,export_time,cost,currency,currency_conversion_rate ,usage.amount ,usage.unit ,usage.amount_in_pricing_units ,usage.pricing_unit FROM [" + tableId + "] WHERE _PARTITIONTIME >= " + timeGranularity.fromDate + " AND _PARTITIONTIME <= " + timeGranularity.toDate + " ORDER BY usage_start_time DESC";	
		}
	}

	return { 
		"query": query, 
		"projectId": projectId 
	};
}

function getTimeGranularity() {
	var granularity = DL.REST.Source.getProperty("timeGranularity");
	var fromDate = "", toDate = "";
	
	if(granularity === 'monthly') {
		fromDate = "USEC_TO_TIMESTAMP(UTC_USEC_TO_MONTH(NOW()))"
		toDate = "DATE_ADD(UTC_USEC_TO_MONTH(DATE_ADD(NOW(), 1, 'month')), -1, 'second')";
	} else if(granularity === 'daily') {
		fromDate = "USEC_TO_TIMESTAMP(UTC_USEC_TO_DAY(DATE_ADD(NOW(), -1, 'day')))";
		toDate = "DATE_ADD(UTC_USEC_TO_DAY(NOW()), -1, 'second')";
	}
	
	return {
		"fromDate": fromDate, 
		"toDate": toDate
	};	
}

function getProjectIdFromQuery(query) {
	var tableId = getTableIdFromQuery(query);
	return getProjectIdFromTableId(tableId);
}

function getTableIdFromQuery(query) {
	return query.substring(query.indexOf("[")+1, query.indexOf("]"))
}

function getProjectIdFromTableId(tableId) {
	return tableId.substring(0, tableId.indexOf(":"));
}

function buildUrlWithJobId(url, jobId) {
    if (url.endsWith('/')) {
        url = url.substr(0, url.length - 1);
    }

    return url + "/" + jobId + "?maxResults=" + maxResults + "&pageToken=";
}

function prepareChunkForUpload(payload) {
    var fields = payload.schema.fields.map(function (field) {
        return {name: field.name, type: field.type};
    });

    var resultsChunk = payload.rows.map(function (row) {
        //f and v are from job results
        var columns = row.f.map(function (column) {
            return column.v;
        });

        var result = {};
        if (fields.length == columns.length) {
            for (var i = 0; i < fields.length; i++) {
                result[fields[i].name] = columns[i];
            }
        }
        return result;
    });

    return { "chunk": resultsChunk };
}

function isValidProjectId(projectId) {
   var url = getProjectsUrl(getBaseUrl());
   DL.logMessage("Making request to " + url);   
   var response = DL.REST.httpGet(url);
   if (response.getCode() == 200) {
       var payload = JSON.parse(response.getPayload());
       var projects = payload.projects;
       
       if (projects !== null && projects.length > 0) {
           var projectIndex = projects.map(function (project) { return project.id; }).indexOf(projectId);

           if (projectIndex !== -1) {
               var availableProject = projects[projectIndex];
               DL.logMessage("Project available : " + JSON.stringify(availableProject));
               return true;
            }
            DL.logMessage("Invalid project id. " + projectId);
            return false;
        } else {
            DL.logMessage("No projects created yet, invalid project id: " + projectId);
            return false;
        }
    } else {
        DL.logMessage("Get projects request failed with status code : " + response.getCode());
        return false;
    }
}