var maxResults = 1000;
var ctJson = "application/json";

function execute() {
    DL.logMessage("****** START EXECUTING OF GOOGLE CLOUD SCRIPT ******");
	
	var queryObject = getQueryObject();

    if (isValidProjectId(queryObject.projectId)) {
        var url = buildJobUrl(queryObject.projectId);
        var body = JSON.stringify(getJobBody(queryObject.query));
		DL.logMessage("Making request to " + url);
		var response = DL.REST.httpPost(url, ctJson, body);
		DL.logMessage("Job creation request completed with status code: " + response.getCode());
		
        if (response.getCode() == 200) {
            var payload = JSON.parse(response.getPayload());
            var jobReference = payload.jobReference;
            if (jobReference !== null && jobReference.jobId) {
                var jobId = jobReference.jobId;
                DL.logMessage("Job created for the query with job id: " + jobId);

                url = buildUrlWithJobId(url, jobId);
                var instanceUrl = url;
                DL.logMessage("Making request to " + url);
                response =  DL.REST.httpGet(url);

                if (response.getCode() == 200) {
                    payload = JSON.parse(response.getPayload());
                    
                    if (payload.rows) {
                        DL.logMessage("****** Starting chunk upload *****");
                        DL.Apptio.startChunkedUpload(ctJson);
                        
                        DL.logMessage("****** Uploading chunk *****");
                        DL.Apptio.uploadChunk(JSON.stringify(prepareChunkForUpload(payload).chunk));

                        while (payload.pageToken) {
                            url = instanceUrl + payload.pageToken;
                            DL.logMessage("Making request to " + url);
                            response = DL.REST.httpGet(url);
                            if (response.getCode() == 200) {
                                payload = JSON.parse(response.getPayload());
                                if (payload.rows) {
                                    DL.logMessage("****** Uploading chunk *****");
                                    DL.Apptio.uploadChunk(JSON.stringify(prepareChunkForUpload(payload).chunk));
                                }
                            } else {
                                DL.logMessage("Failed to retrieve remaining records; uploading current set");
                                break;
                            }
                        }

                        DL.Apptio.endChunkedUpload();
                        DL.logMessage("****** Upload chunk completed *****");
                    } else {
                        DL.logMessage("No records found!");
                    }
                } else {
                    DL.logMessage("Failed to retrieve job details with status code: " + response.getCode());    
                }

            } else {
                DL.logMessage("Failed to create job.");  
            }
        } else {
            DL.logMessage("Failed to create job with status code: " + response.getCode());
        }
    } else {
        DL.logMessage("Invalid Project Id.");
    }
}

function test() {
    DL.logMessage("****** START TESTING SCRIPT - GOOGLE CLOUD ******");

    var queryObject = getQueryObject();
    if (queryObject.projectId !== null) {
        var url = getBaseUrl() + "/bigquery/v2/projects";

        var response = DL.REST.httpGet(url);
        if(response.getCode() === 200) {
            DL.logMessage("Google Cloud URL and credentials are valid.");
        } else {
            DL.terminate("Request failed with status code " + response.getCode());
        }
    } else {
        DL.logMessage("***** Project Id is empty *****");
    }
}

function getBaseUrl() {
    var baseUrl = DL.REST.Source.getUrl();
    var url = DL.REST.rebuildUrl(baseUrl, true, false, false, false);
    if (url.endsWith('/')) {
        url = url.substr(0, url.length - 1);
    }
    return url;
}

function buildJobUrl(projectId) {
    return getJobUrl(getProjectsUrl(getBaseUrl()), projectId);
}

function getJobUrl(url, projectId) {
    return url + projectId + "/queries";
}

function getProjectsUrl(url) {
    return url + "/bigquery/v2/projects/";
}

function getJobBody(query) {
	return {
        "query"         : query,
        "maxResults"    : maxResults,
        "useLegacySql"  : true
    };
}

function getQueryObject() {
	var query = DL.REST.Source.getProperty("bigQuery").trim();
	var projectId = "";

	if (query) {
		projectId = getProjectIdFromQuery(query);
	} else {
		var tableId = getTableId();
		if (tableId) {
			projectId = getProjectIdFromTableId(tableId);
            query = getQueryByGranularity(tableId);
		}
	}

	return { 
		"query": query, 
		"projectId": projectId 
	};
}

function getQueryByGranularity(tableId) {
    var timeGranularity = getTimeGranularity();
    var granularity = "%Y-%m";
    if(timeGranularity.granularity === "daily") {
        granularity = "%Y-%m-%d";
    }

    return "SELECT service.description as serviceName, sku.description as skuDescription, STRFTIME_UTC_USEC(usage_start_time, '" + granularity + "') as usage_start_time, STRFTIME_UTC_USEC(usage_end_time, '" + granularity + "') as usage_end_time, STRFTIME_UTC_USEC(_PARTITIONTIME, '" + granularity + "') as partitiontime, project.id as  projectId, project.name as projectName, sum(cost) as cost, currency, currency_conversion_rate, sum(usage.amount) as usage_amount, usage.unit, sum(usage.amount_in_pricing_units) as  usage_amount_in_pricing_units, usage.pricing_unit FROM [" + tableId + "] WHERE _PARTITIONTIME >= " + timeGranularity.dateRange.fromDate + " AND _PARTITIONTIME <= " + timeGranularity.dateRange.toDate + " group by partitiontime, usage_start_time, usage_end_time, serviceName, skuDescription, projectId, projectName, currency, currency_conversion_rate, usage.unit, usage.pricing_unit order by skuDescription, partitiontime desc";	
}

function getTableId() {
    var tableId = DL.REST.Source.getProperty("tableId").trim();

    if (tableId.endsWith(']')) {
        tableId = tableId.substr(0, tableId.length - 1);
    }

    if (tableId.startsWith('[')) {
        tableId = tableId.substr(1, tableId.length - 1);
    }

    return tableId;
}

function getTimeGranularity() {
    var timeGranularity = DL.REST.Source.getProperty("timeGranularity");
    var dateRange = getDateRange(getTimePeriod());

    return {
		"dateRange"     : dateRange, 
        "granularity"   : timeGranularity
	};
}

function getDateRange(dateTime) {
    return {
        "fromDate"  : "USEC_TO_TIMESTAMP(UTC_USEC_TO_MONTH("+ dateTime +"))",
        "toDate"    : "DATE_ADD(UTC_USEC_TO_MONTH(DATE_ADD("+ dateTime +", 1, 'month')), -1, 'second')"
    }
}

function getTimePeriod() {
    var timePeriod = DL.REST.Source.getProperty("timePeriod");
    var period = "NOW()";
    DL.logMessage("Time Period: "+ timePeriod.toLowerCase());
    
    if(timePeriod && timePeriod.toLowerCase() === "previous") {
        period = "DATE_ADD(NOW(), -1, 'month')";
    }
    return period;
}

function getProjectIdFromQuery(query) {
	var tableId = getTableIdFromQuery(query);
	return getProjectIdFromTableId(tableId);
}

function getTableIdFromQuery(query) {
	return query.substring(query.indexOf("[")+1, query.indexOf("]"))
}

function getProjectIdFromTableId(tableId) {
	return tableId.substring(0, tableId.indexOf(":"));
}

function buildUrlWithJobId(url, jobId) {
    if (url.endsWith('/')) {
        url = url.substr(0, url.length - 1);
    }

    return url + "/" + jobId + "?maxResults=" + maxResults + "&pageToken=";
}

function prepareChunkForUpload(payload) {
    var fields = payload.schema.fields.map(function (field) {
        return {name: field.name, type: field.type};
    });

    var resultsChunk = payload.rows.map(function (row) {
        //f and v are from job results
        var columns = row.f.map(function (column) {
            return column.v;
        });

        var result = {};
        if (fields.length == columns.length) {
            for (var i = 0; i < fields.length; i++) {
                result[fields[i].name] = columns[i];
            }
        }
        return result;
    });

    return { "chunk": resultsChunk };
}

function isValidProjectId(projectId) {
   var url = getProjectsUrl(getBaseUrl());
   DL.logMessage("Making request to " + url);   
   var response = DL.REST.httpGet(url);
   if (response.getCode() == 200) {
       var payload = JSON.parse(response.getPayload());
       var projects = payload.projects;
       
       if (projects !== null && projects.length > 0) {
           var projectIndex = projects.map(function (project) { return project.id; }).indexOf(projectId);

           if (projectIndex !== -1) {
               var availableProject = projects[projectIndex];
               DL.logMessage("Project available : " + JSON.stringify(availableProject));
               return true;
            }
            DL.logMessage("Invalid project id. " + projectId);
            return false;
        } else {
            DL.logMessage("No projects created yet, invalid project id: " + projectId);
            return false;
        }
    } else {
        DL.logMessage("Get projects request failed with status code : " + response.getCode());
        return false;
    }
}